function filtered_signal=myfilteronefreq(Fs,signal,frequency_to_leave_in_signal)
%MYFILTERONEFREQ Bandpass filter on a matrix of signals
%
% The filtered signals are obtained by convoluting a sinusoid of the
% specified frequency on each of the signals
% 
% in:
% Fs        1       Sampling frequency
% signal    n x 2   Input signals
% frequency_to_leave_in_signal
%           1       frequency at the center of the bandpass
%
% out:
% filtered_signal   signal containing only the bandpassed frequencies
% This file is provided WITHOUT ANY WARRANTY
%
% Created by Massimiliano Di Luca 19/08/2009
% max@tuebingen.mpg.de
%
%
%
% Modified max 12/09/2009 cleaned up


n_repeated_cycles=5;
filtered_signal=signal*0; %preallocation
angle_vector=(1/frequency_to_leave_in_signal/4+(1/Fs:1/Fs:1/frequency_to_leave_in_signal*n_repeated_cycles))*2*pi*frequency_to_leave_in_signal;%time vector
length_signal=length(angle_vector);
gaussian_window=normpdf(1/Fs:1/Fs:1/frequency_to_leave_in_signal*n_repeated_cycles,1/frequency_to_leave_in_signal*n_repeated_cycles/2,1/frequency_to_leave_in_signal*n_repeated_cycles/2/2);

kernel=sin(angle_vector).*gaussian_window;%creates a kernel signal, a sinusoid with frequency frequency_to_leave_in_signal and Gaussian amplitude envelope
%plot(kernel)

for sig12=1:size(signal,2)
    signalt=conv(kernel,signal(:,sig12))/length_signal;%convolution of the signal with the kernel
    filtered_signal(:,sig12)=-signalt(ceil(length_signal/2):1:length(signalt)-floor(length_signal/2));%convolution produces an output that has more elements than the input, so the additional elements need to be taken out
end


filtered_signal=filtered_signal./repmat(std(filtered_signal),size(filtered_signal,1),1);
