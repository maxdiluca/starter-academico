% This software is provided as a complement to the manuscript "A new method
% to measure delay of VR" by Massimiliano Di Luca submitted to Presence. It 
% allows the implementation of the method to measure the delay of a VR system
% using two photodiodes and two gradients with different frequencies of
% motion and then characterize the frequency characteristics of the VR system.
%
% By using the two photodiodes plugged into the audio card and two gradients
% (one statically displayed on a LCD screen, the other displayed in the VR
% environment on a polygon surface) it is possible to record virtual and
% physical trajectories of the HMD. These recordings should be performed
% multiple times at different frequencies. The analysis script allows then
% estimate frequency of movements and delay for each of them.
% 
% The software is provided without any warranty or support
% You are free to use this software, but you should acknowledge the source.
% 
% 
% 
% max@tuebingen.mpg.de
% 
% Massimiliano Di Luca, PhD
% Max Planck Institute for Biological Cybernetics
% Human Perception, Action and Cognition
% Spemannstr 41 72076 T�bingen Germany
% voice	+49 (0)7071 601 641
% fax		+49 (0)7071 601 616
% web		www.kyb.mpg.de/~max
% 
% 
% V1.2
% 
% Contents:
% 
% * test_{1/2}_{1/2/3/4}.mat
% 
% Two series of example recordings to test the program calculate_delay_gui 
% 
% * test_recording.m 
% 
% File that checks the audio card and guides the user through the different steps of the process. It continuously displays the recorded signals and makes you perform different checks.
% 
% * signal_recording.m 
% 
% Simple utility that records audio signals for a specified time and saves them.
% 
% * calculate_delay_gui.m
% 
% Loads a series of files and derives the latency and frequency of each of them. It then plots the transfer function obtained.
% 
% To analyze the series of recordings provided as example follow these steps: select one file of the test recording files, select the letter "1" or "2" after the first "_", select "no" inverse gradient, and select "I'm not sure" for which channel is delayed. The analysis test_1 goes smooth without need for much interaction. The analysis of test_2 requires some user adjustments of the sliders.
% 
% For systems 
% 
% 
% 
% Other required files for calculate_delay_gui and included in the folder:
% 
% * myfilteronefreq.m
% 
% Bandpass filter around a single frequency 
% 
% * finddelay.m
% 
% Cross correlation to determine the delay between two signals
% 
% * fsplot.m
% 
% plots one distribution on the top graph and two or three signals on the bottom
% 
% * findfreq.m
%
% Finds the peak in the spectral content of two signals.
