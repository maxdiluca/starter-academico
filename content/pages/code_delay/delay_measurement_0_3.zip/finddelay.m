function [delaymaxcorrelation,correlations]=finddelay(signal,max_delay_expected,Fs,direction_delay)
%FINDDELAY Correlation coefficients and delay that maximizes it
%
% [delaymaxcorrelation,crosscorrelation]=finddelay(signal,max_delay_expected,Fs,direction_delay)
%
% Calculates the cross-correlation between the two columns of the variable
% signal (sampled at the frequency Fs) and calculates the delay
% corresponding to maximum correlation. 
%
% in:
% signal                    n x 2   matrix with the two signals recorded
% max_delay_expected        1       only cross correlation with absolute delay
%                                   smaller than this value will be considered 
% Fs                        1       sampling frequency 
% (opt) direction_delay     1       0: both sides of delays (+/-) are considered
%                                   1/-1: only one side of the crossc orrelation
% out:
% delaymaxcorrelation - delay that maximizes the coherence between the
%   signals
% correlations - correlation values for delaymaxcorrelation between -max_delay_expected
%   and max_delay_expected at 1/Fs steps 
%
% This file is provided WITHOUT ANY WARRANTY
%
% Created by Massimiliano Di Luca 05/10/2009
% max@tuebingen.mpg.de


if nargin<4
    direction_delay=0;
end
%cross-correlation of the two signals done in the frequency domain
a = ifft(fft(signal(:,2)) .* conj(fft(signal(:,1))))/size(signal,1);

%delaymaxcorrelation is maximum value of a either at one end or the other of a
%a can be reshaped to form the crosscorrelation coefficient

c=a(1:max_delay_expected*Fs);
d=flipud(a);
correlations=[flipud(c); d(1:(max_delay_expected*Fs+1))];

if direction_delay==0% both directions possible
    c=a(1:max_delay_expected*Fs);
    d=flipud(a);
    b=[flipud(c); d(1:(max_delay_expected*Fs+1))];
    delaymaxcorrelation=find(b == max(b))/Fs-max_delay_expected;
elseif direction_delay>0
    d=flipud(a);
    b=d(1:(max_delay_expected*Fs+1));
    delaymaxcorrelation=(find(b == max(b))-1)/Fs;
else %%direction_delay<0
    b=a(1:max_delay_expected*Fs);
    delaymaxcorrelation=-find(b == max(b))/Fs;
end

