function test_recording(Fs,nbits)
%TEST_RECORDING Step by step setup of audio card
%
% in:
% (opt) Fs              desired sampling frequency
% (opt) nbits           desired resolution of the A/D converter
%
% This code will guide you through all necessary steps to setup the
% measurement of end-to-end delay of VR setups. You need to read and
% perform each action described in the command line window and also look at
% the output figure to check if the signal is captured correctly
%
% The program uses the audiorecorder class
%
%
% This file is provided WITHOUT ANY WARRANTY
%
% Created by Massimiliano Di Luca 05/08/2009
% max@tuebingen.mpg.de
%
%
%
% Modified max 12/09/2009 added text instructions
% Modified max 14/10/2009 fine tuned
% Modified max 14/06/2010 got rid of mouse interaction
% Modified max 09/02/2011 fixed Fs variable and initialization



if nargin==0
    clc
    Fs=8000;
    nbits=16;
end


try
    handeforaudiorecorder = audiorecorder(Fs, nbits, 2);
    disp(['Initialization of audiocard is correct using ' int2str(handeforaudiorecorder.SampleRate) 'Hz sampling frequency and ' int2str(handeforaudiorecorder.BitsPerSample) ' bits per sample resolution'])
catch
    try
        handeforaudiorecorder = audiorecorder(Fs, nbits, 1);
        disp('Error in the initialization: does your audio card have a STEREO line in?')
        lasterr
        return
    catch
        try
            handeforaudiorecorder = audiorecorder;
            disp(['Error in the initialization: your audio device does not support a ' int2str(Fs) 'Hz sampling frequency or a ' int2str(nbits) ' bits per sample resolution'])
            test_recording(handeforaudiorecorder.SampleRate,handeforaudiorecorder.BitsPerSample);
            
        catch
            lasterr
            return
        end
    end
end

%some resetting in case it's not the first recording
try
    stop(handeforaudiorecorder)
    record(handeforaudiorecorder);
    stop(handeforaudiorecorder)
    getaudiodata(handeforaudiorecorder); 
     disp('Test recording executed correctly')
catch
    lasterr
    disp('Error while performing the test recording')
end

disp('click here with the mouse (in the command window) and press any key to continue')
pause

disp('Connect the photodiodes to the line-in connector of your audio card')
disp('The signals recorded from the two channels will be displayed and updated continuously')
disp('Note that the numbers followed by an asterisk will require you to check the graph with the recorded signal')
disp('Things to notice:')
disp('LIGHTS ON')
disp('1*) if there is a change in the line while you produce some noise, you are not recording from the line in but from the microphone')
disp('   depending on your OS you need to change the recording source to line-in')
disp('2*) if the two lines are almost identical and flat, you either didn''t connect the diodes to the correct input or you are recording from the wrong source ')
disp('   depending on your OS you need to change the recording source to line-in or raise the volume of the input')
disp('3*) if you shine a light on each of the two photodiodes you should see a change in the signals')
disp('   test both channel and identify which one is the green channel and put a label on it')
disp('')
disp('press a button to start displaying the signals (and close the window to stop)')
pause

graphic_loop(handeforaudiorecorder,Fs)


clc
disp('4) display the virtual scene with the surface where to display the images')
disp('5) wear the HMD and find the position and orientation of the HMD so that the VR view is limited to')
disp('    a small portion at the center of the gradient. No other part of the scene shoul be visible')
disp('6) memorize the position of the HMD so that it can be precisely reproduced')
disp('7) attach the photodiodes to the HMD keeping the green diode outside')
disp('8) put the HMD to the memorized position')
disp('9) put the LCD near the green photodiode, so that it faces the center of the screen at about 1 inch from it')
disp('10) display the black-white border on both the VR surface and the HMD.')
disp('LIGHTS OFF')
disp('11*) move the HMD across the border and notice the change in both signals')
disp('')
disp('press a button to start displaying the signals (and close the window to stop)')
pause


graphic_loop(handeforaudiorecorder,Fs)


disp('12) display the gradient on both the VR surface and the HMD')
disp('13) move the HMD at the brighter side of the gradient (right) without reaching the border of the LCD')
disp('14) check in the HMD that the gradient in the virtual scene does not reach the borders either but there is a modulation of luminance')
disp('15) repeat 11 and 12 for the left side')

disp('16) practice sinusoidal horizontal movements of the HMD so that they span most of the width without')
disp('      reaching the borders either of the LCD or of the virtual surface')

disp('17*) in the next figure notice whether both signals have modulations due to the movement')
disp('')
disp('press a button to start displaying the signals (and close the window to stop)')
pause

graphic_loop(handeforaudiorecorder,Fs)




disp('you are now ready to record a signal')
disp(' ')
disp('now execute: ')
disp('signal_recording')





function graphic_loop(handeforaudiorecorder,Fs)


record(handeforaudiorecorder);
iff=get(0,'CurrentFigure');
if isempty(iff)
    iff=-9;
end
iff=figure(iff+10);
cla
iff_original=iff;

set(iff,'name','Close this window to continue')


flag=0;
while flag==0
    try
        stop(handeforaudiorecorder)
        recorded_signal = getaudiodata(handeforaudiorecorder);
        record(handeforaudiorecorder);
        figure(iff);
        if get(0,'CurrentFigure')==iff_original
            plot(1/Fs:1/Fs:size(recorded_signal,1)/Fs,[recorded_signal(:,1)+0.51 recorded_signal(:,2)+.49])
            axis([0 1.2 0 1])
            
        else
            stop(handeforaudiorecorder)
            flag=-1;
            
            break
        end
    catch
        lasterr
        pause
        break
    end
    
end