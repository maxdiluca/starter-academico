%CALCULATE_DELAY_GUI  Frequency and delay estimates for series of recordings
% Loads a series of files created by signal_recording to analyzes the two
% signals contained in each of the files and find how much they are shifted apart in time.
% It requires the selection of one .mat file that composes the series of
% recordings, which should contain a n x 2 matrix. The file might contain
% the sampling frequency Fs, otherwise it has to be specified.
% The program requires to select whiter the two gradients used for the
% recordings were inverse to each other (signal two will be reversed,
% if this is the case).
% It also requires to select which of the two signals is the delayed one,
% to avoid false measurements. If this information is unknown, both types
% of delay will be considered in the analysis.
%
% For each of the files:
% 1) The program filters the signals outside of the expected range of movement frequencies
% 2) The signals are downsampled and windowed
% 3) The spectrum composing the signal is computed to find the most
% prominent frequency of HMD movements
% 4) The signal are filtered to leave only the most prominent frequency
% 5) To find the delay, the program calculates the cross correlation that makes the two signals match
%
% To work, the file requires the filtfilt function from the signal toolbox
%
% It also utilizes findfreq, finddelay, fsplot, and myfilteronefreq
%
% This file is provided WITHOUT ANY WARRANTY
%
%
%
% % Use this code to generate a series of signals at different frequencies
% and latencies. Random noise can be added before saving the signal to
% test the efficacy of the algorithm
% Fs=8000;
% delay=.05;
% frequency=0.7;
% rampdur=2
% tt=(1/Fs:1/Fs:10);
% signal(:,1)=sin(tt*frequency*2*pi)';
% signal(:,2)=sin(delay*frequency*2*pi+tt*frequency*2*pi)';
% sinusoidal_window=[.5-cos(pi*(1/Fs:1/Fs:rampdur)/rampdur)/2 ones(1,size(signal,1)-rampdur*Fs*2) cos(pi*(1/Fs:1/Fs:rampdur)/rampdur)/2+.5];
% signal=signal.*[sinusoidal_window' sinusoidal_window'];
% save(['ftestsignal' num2str(frequency,'%2.2f') num2str(delay,'%2.2f') '.mat'], 'signal', 'Fs')
%
%
%
% Created by Massimiliano Di Luca 26/12/2004
% max@tuebingen.mpg.de
%
%
%
% Modified max 12/05/2009 added correlation instead of signal shifting
% Modified max 04/06/2009 added ifft instead of correlation
% Modified max 01/08/2009 refined filtering
% Modified max 13/08/2009 added file selection
% Modified max 20/08/2009 changed filtering section
% Modified max 09/10/2009 commented
% Modified max 18/10/2009 added ui ingterfaces
% Modified max 20/10/2009 ui interfaces are hard
% Modified max 24/10/2009 ui interfaces are buggy
% Modified max 30/10/2009 max vs. ui interfaces: 3-2


clc
clear all
close all

%Latencies above this value will not be detected
max_delay_expected=.2;

%Frequency of the downsampled recorded signals (to save CPU time)
Fsr=1000;

% % Important: the range of frequencies is not infinite (try to oscillate the
% HMD at 10Hz and notice it's impossible). Lowering the range very low causes
% problem to the algo. However, analyzing signals that are near the lower
% range can give an underestimate of delay (about 5 ms at .3 Hz). The step
% size determines the precision of the analysis but also execution time
min_freq=.3;
max_freq=4;
steps_freq=500;
range_of_movement_frequencies=min_freq:(max_freq-min_freq)/(steps_freq-1):max_freq;


freq_smoothing=max(range_of_movement_frequencies);
freq_filter_highpass=min(range_of_movement_frequencies);

if exist('filtfilt','file')==0
    disp('This program requires the filtfilt function, part of the signal toolbox')
    return
end

if exist('findfreq','file')==0
    disp('This program requires the findfreq function, which should be part of the distribution and be in the same directory as this file')
    return
end

if exist('finddelay','file')==0
    disp('This program requires the finddelay function, which should be part of the distribution and be in the same directory as this file')
    return
end

if exist('myfilteronefreq','file')==0
    disp('This program requires the myfilteronefreq function, which should be part of the distribution and be in the same directory as this file')
    return
end

if exist('fsplot','file')==0
    disp('This program requires the fsplot function, which should be part of the distribution and be in the same directory as this file')
    return
end


%A UI is used to select one of the files in the series of measurements
%performed. The first few letters of the file should univocally identify
%the series of files.

disp('Select one of the files to analyze')

[filename,pathname] = uigetfile('*.mat','Select one of the mat files with the recording to import and analyze');

if filename==0
    return
end

disp(['You selected the file: ' filename])

namecommonnumber = menu(['You selected the file: ' filename ' . How many letters of the filename uniquely identify the series?'], cellstr(filename')) ;

opposite_gradients = menu('Were the gradients opposite to each other?.','Yes','No') ;
opposite_gradients=-opposite_gradients+2;

direction_delay = menu('Which channel recorded from inside the HMD (so it is delayed)?','1','I''m not sure','2') ;
direction_delay=direction_delay-2;

%namecommonnumber=input('How many letters of the filename are equal in the series of measurements? ','s');

disp([ 'Looking for files starting with the string: ' filename(1:namecommonnumber)])
files=dir([pathname '/' filename(1:namecommonnumber) '*']);

disp([int2str(size(files,1)) ' files will be anaylized'])

totalvars=zeros(100,3);

%h=figure('Position',[501 0 500 350]);

%iff=figure(10);
screensize = get(0,'ScreenSize');
screensize(3)=min(screensize(3),800);
screensize(4)=min(screensize(4),600);

%set(iff,'Position',[screensize(1) screensize(2) screensize(3) screensize(4)]);


%Loop through the series of files and analyze each one of them separately
nfilerec=0;
for nfile=1:size(files,1)
    filename=files(nfile).name;
    nfilerec=nfilerec+1;

    clear Fs

    if isequal(filename,0)
        disp('User selected Cancel')
        return
    else
        disp(['********  Now loading file: ', fullfile(pathname, filename)])
        load(fullfile(pathname, filename))
    end

    try
        disp(['Fs=' int2str(Fs) '  ' int2str(size(signal,1)) ' samples in the signals'])
    catch
        disp('Select sampling frequency')
        Fss={'8000','11025','22050','44100'};
        k = menu('The file selected does not specify the sampling frequency used.',Fss) ;
        Fs=eval(cell2mat(Fss(k)));
    end



    %signal variables
    signal_duration=size(signal,1)/Fs;

    %series of "ones" used for smoothing and filtering
    bs = ones(1,round(Fs/2/freq_smoothing))/round(Fs/2/freq_smoothing);
    bl = ones(1,round(Fsr/2/freq_filter_highpass))/round(Fsr/2/freq_filter_highpass);

    %windowing function to take away beginning and end of the signal
    window_envelope_funcionr=normpdf(1/Fsr:1/Fsr:signal_duration,signal_duration/2,signal_duration/2);
    window_envelope_funcionr=(window_envelope_funcionr-min(window_envelope_funcionr))/(max(window_envelope_funcionr)-min(window_envelope_funcionr));


    %take out mean
    signal=signal-repmat(mean(signal),size(signal,1),1);
    

    %if the two gradients are opposite to each other use
    if opposite_gradients==1
        signal(:,1)=- signal(:,1);
    end

    %normalize for amplitude
    signal=signal./repmat(max(abs(signal)),size(signal,1),1);

    %useful for debugging
    %signaloriginal=signal;

    %low-pass, downsample, and then high-pass
    clear signalr signalrr signalt signalf signalm;
    signal(:,1)=filtfilt(bs,1,signal(:,1));
    signal(:,2)=filtfilt(bs,1,signal(:,2));

    %take out mean
    signal=signal-repmat(mean(signal),size(signal,1),1);

    %normalize for amplitude
    signal=signal./repmat(max(abs(signal)),size(signal,1),1);


    %resample at lower frequency
    signalr(:,1)= interp1(1/Fs:1/Fs:signal_duration,signal(:,1),1/Fsr:1/Fsr:signal_duration,'nearest');
    signalr(:,2)= interp1(1/Fs:1/Fs:signal_duration,signal(:,2),1/Fsr:1/Fsr:signal_duration,'nearest');

    %highpass (by first lowpassing and then removing what's left)
    signalt(:,1)=filtfilt(bl,1,signalr(:,1));
    signalrr(:,1)=signalr(:,1)-signalt(:,1);
    signalt(:,2)=filtfilt(bl,1,signalr(:,2));
    signalrr(:,2)=signalr(:,2)-signalt(:,2);

    %windowing
    signalrr=signalrr-repmat(mean(signalrr),size(signalrr,1),1);
    signalrr=signalrr.*[window_envelope_funcionr' window_envelope_funcionr'];
    signalrr=signalrr-repmat(mean(signalrr),size(signalrr,1),1);

    %find the spectrum and the frequency of movements in the signal
    [freqsignal,spectrum]=findfreq(signalrr,Fsr,range_of_movement_frequencies);

    signalm=myfilteronefreq(Fsr,signalrr,freqsignal);
    delay=finddelay(signalm,max_delay_expected,Fsr,direction_delay);
    delaysinsin=finddelay([signalm(:,1) sin(((1/Fsr:1/Fsr:signal_duration))*freqsignal*2*pi)'*max(max(signalm(:,1)))/2] ,max_delay_expected,Fsr);


    %some UI stuff 1st pass *****************************

    iff=figure;
    clf
    set(iff,'Position',[screensize(1) screensize(2) screensize(3) screensize(4)]);
    poswin=get(iff,'Position');
    widthw=poswin(3);
    heightw=poswin(4);

    [p1,p2]=fsplot(iff,freqsignal,delaysinsin,delay,range_of_movement_frequencies,spectrum,Fsr,[signalrr(:,1)/std(signalrr(:,1)) signalm(:,1)/std(signalm(:,1))]);

    buttonOK = uicontrol('Style', 'pushbutton', 'String', 'OK',...
        'Position', [1 50 50 50], 'Callback', 'buttonval=1;');
    buttonQUIT = uicontrol('Style', 'pushbutton', 'String', 'QUIT',...
        'Position', [1 1  50 50], 'Callback', 'buttonval=-1;');

    sliderselectfreq = uicontrol(iff,'Style','slider',...
        'Max',max(range_of_movement_frequencies),'Min',min(range_of_movement_frequencies),'Value',freqsignal,...
        'SliderStep',[1/steps_freq 10/steps_freq],...
        'Callback',...
        'freqsignal = get(sliderselectfreq,''Value'');signalm=myfilteronefreq(Fsr,signalrr,freqsignal);delay=finddelay(signalm,max_delay_expected,Fsr);delaysinsin=finddelay([signalm(:,1) sin(((1/Fsr:1/Fsr:signal_duration))*freqsignal*2*pi)''*max(max(signalm(:,1)))/2] ,max_delay_expected,Fsr);set(sliderselecttime,''Value'',delaysinsin);fsplot(iff,freqsignal,delaysinsin,delay,range_of_movement_frequencies,spectrum,Fsr,[signalrr(:,1)/std(signalrr(:,1)) signalm(:,1)/std(signalm(:,1))]);',...
        'Position',[p1(1)*widthw  p1(2)*heightw-50  p1(3)*widthw+20*2 20]);

    sliderselectfreqtext = uicontrol(iff,'Style','text','Position',[p1(1)*widthw+p1(3)*widthw+20*2  p1(2)*heightw-50  30 20] ,'String','Freq');


    sliderselecttime = uicontrol(iff,'Style','slider',...
        'Value',delaysinsin,...
        'Max',1 ,'Min',-1,...
        'SliderStep',[.01 .1],...
        'Callback',...
        'delaysinsin = get(sliderselecttime,''Value'');fsplot(iff,freqsignal,delaysinsin,delay,range_of_movement_frequencies,spectrum,Fsr,[signalrr(:,1)/std(signalrr(:,1)) signalm(:,1)/std(signalm(:,1))]);',...
        'Position',[widthw/2-p1(3)/signal_duration*widthw*1.5  p2(2)*heightw-50  p1(3)/signal_duration*widthw*2*1.5 20]);

    sliderselecttimetext = uicontrol(iff,'Style','text','Position',[p1(1)*widthw+p1(3)*widthw+20*2  p2(2)*heightw-50  30 20] ,'String','Delay');

    sthtit = uicontrol(iff,'Style','text','Position',[1 heightw-30 widthw 30],'String','Adjust the frequency slider (top) to match the frequency of the blue and red signals, then press ok');

    set(sliderselecttime,'Value',delaysinsin);

    buttonval=0;
    while buttonval==0
        try

            poswin=get(iff,'Position');
            widthw=poswin(3);
            heightw=poswin(4);
            [p1,p2]=fsplot(iff,freqsignal,delaysinsin,delay,range_of_movement_frequencies,spectrum,Fsr,[signalrr(:,1)/std(signalrr(:,1)) signalm(:,1)/std(signalm(:,1))]);

            set(sliderselectfreq,'Position',[p1(1)*widthw  p1(2)*heightw-50  p1(3)*widthw+20*2 20])
            set(sliderselectfreqtext,'Position',[p1(1)*widthw+p1(3)*widthw+20*2  p1(2)*heightw-50  30 20])

            set(sliderselecttime,'Position',[widthw/2-p1(3)*widthw/signal_duration*1.5  p2(2)*heightw-50  p1(3)*widthw/signal_duration*2*1.5 20])
            set(sliderselecttimetext,'Position',[p1(1)*widthw+p1(3)*widthw+20*2  p2(2)*heightw-50  30 20] )

            set(sthtit,'Position',[1 heightw-20 widthw 20])
            set(buttonOK,'Position',[1 50 50 50])
            set(buttonQUIT,'Position',[1 1  50 50])
            set(sthtit,'Position',[1 heightw-30 widthw 30])
        catch
            lasterr
            buttonval=-1;
        end

    end

    close(iff)
    if buttonval==-1
        return
    end

    %some UI stuff  2nd pass *****************************

    signalm=myfilteronefreq(Fsr,signalrr,freqsignal);
    signalm=signalm./repmat(std(signalm),size(signalm,1),1);
    [delay,b]=finddelay(signalm,max_delay_expected,Fsr,direction_delay);

    iff=figure;
    set(iff,'Position',[screensize(1) screensize(2) screensize(3) screensize(4)]);
    poswin=get(iff,'Position');
    widthw=poswin(3);
    heightw=poswin(4);
    clf


    p1=fsplot(iff,freqsignal,999,delay,-max_delay_expected:1/Fsr:max_delay_expected,b,Fsr,signalm);

    buttonOK = uicontrol('Style', 'pushbutton', 'String', 'OK',...
        'Position', [1 50 50 50], 'Callback', 'buttonval=1;');
    buttonQUIT = uicontrol('Style', 'pushbutton', 'String', 'QUIT',...
        'Position', [1 1  50 50], 'Callback', 'buttonval=-1;');

    sliderselecttime2 = uicontrol(iff,'Style','slider',...
        'Value',max(-max_delay_expected,min(delay,max_delay_expected)),...
        'Max',max_delay_expected ,'Min',-max_delay_expected,...
        'SliderStep',[10 1]/(max_delay_expected*Fsr*2-1)/100,...
        'Callback',...
        'delay = get(sliderselecttime2,''Value'');fsplot(iff,freqsignal,999,delay,-max_delay_expected:1/Fsr:max_delay_expected,b,Fsr,signalm);',...
        'Position',[p1(1)*widthw  p1(2)*heightw-50  p1(3)*widthw+20*2 20]);

    sliderselecttimetext = uicontrol(iff,'Style','text','Position',[p1(1)*widthw+p1(3)*widthw+20*2  p1(2)*heightw-50  30 20] ,'String','Delay');

    sthtit = uicontrol(iff,'Style','text','Position',[1 heightw-30 widthw 30],'String','Adjust the delay slider to match the timing of the blue and red signals, then press ok');


    buttonval=0;
    while buttonval==0
        try

            figure(iff)
            poswin=get(iff,'Position');
            widthw=poswin(3);
            heightw=poswin(4);
            p1=fsplot(iff,freqsignal,999,delay,-max_delay_expected:1/Fsr:max_delay_expected,b,Fsr,signalm);


            set(sliderselecttime2,'Position',[p1(1)*widthw  p1(2)*heightw-50  p1(3)*widthw+20*2 20]);

            set(sliderselecttimetext,'Position',[p1(1)*widthw+p1(3)*widthw+20*2  p1(2)*heightw-50  30 20] )

            set(sthtit,'Position',[1 heightw-20 widthw 20])
            set(buttonOK,'Position',[1 50 50 50])
            set(buttonQUIT,'Position',[1 1  50 50])
            set(sthtit,'Position',[1 heightw-30 widthw 30])
        catch
            lasterr
            buttonval=-1;
        end

    end
    close(iff);
    if buttonval==-1
        return
    end


    %some UI stuff  3rd pass *****************************

    iff=figure;
    clf
    set(iff,'Position',[screensize(1) screensize(2) screensize(3) screensize(4)]);
    poswin=get(iff,'Position');
    widthw=poswin(3);
    heightw=poswin(4);


    buttonOK = uicontrol('Style', 'pushbutton', 'String', 'Keep',...
        'Position', [1 50 50 50], 'Callback', 'buttonval=1;');
    buttonQUIT = uicontrol('Style', 'pushbutton', 'String', 'QUIT',...
        'Position', [1 1  50 50], 'Callback', 'buttonval=-1;');
    buttonrename = uicontrol('Style', 'pushbutton', 'String', 'RENAME',...
        'Position', [50 1 50 50], 'Callback', 'buttonval=-2;');
    uicontrol(iff,'Style','text',...
        'String',' ',...
        'Position',[10 400 500 20],'String','mark this file not to be used any more? ');

    buttonval=0;
    while buttonval==0
        %  slider_value = get(hObject,'Value');

        try
            poswin=get(iff,'Position');
            figure(iff)
            hold on
            plot(1/Fs:1/Fs:signal_duration,signal(:,1))
            hold on
            plot(1/Fs:1/Fs:signal_duration,circshift(signal(:,2),round(delay*Fs)),'r')
            set(buttonOK,'Position',[1 50 50 50])
            set(buttonrename,'Position',[1 1  50 50])
            set(buttonQUIT,'Position',[50 1  50 50])
            uicontrol(buttonOK)
            % uicontrol(buttonrename)
        catch
            lasterr
            buttonval=1;
        end

    end
    close(iff);
    if buttonval==-1
        return
    end
    pause(.1)



    if buttonval==-2
        rename = menu('Are you sure you want to rename the file so not to be used any more?','Yes','No') ;
        if rename==1
            movefile(fullfile(pathname, filename),fullfile(pathname, ['notthis_' filename]))
            nfilerec=nfilerec-1;
        else
            totalvars(nfilerec,:)=[(delay)*1000  max(b) freqsignal];

        end
    else
        totalvars(nfilerec,:)=[(delay)*1000  max(b) freqsignal];
    end

    close all;
end

%done analyzing the single files
totalvars=totalvars(1:nfilerec,:);
totalvars=sortrows(totalvars,3);

%final plotting

figure(100)
plot(totalvars(:,3),totalvars(:,1),'o','MarkerEdgeColor','r','MarkerFaceColor','k','LineWidth',2,    'MarkerSize',10)
hold on
plot([0 max(range_of_movement_frequencies)],[0 0],'k')
hold off
ylabel('Delay [ms]')
axis([0 max(range_of_movement_frequencies) min([totalvars(:,1)*1.2;0]) max([totalvars(:,1)*1.2;10])])
xlabel('Movement frequency [Hz]')

%final display

disp('The average delay (disregarding any frequency characteristics if present) is:')
disp([num2str(mean(totalvars(:,1)),'%2.2f') ' ms +/- ' num2str(std(totalvars(:,1))/sqrt(size(totalvars,1)),'%2.2f') ' ms (s.e.m.)'])
disp('The individual latencies for each signal recorded are:')
disp(' ')
disp(' Delay[ms] Accuracy(0-1) Frequency[Hz]' )
disp(totalvars)

disp('The variable '' totalvars '' contains these values and it is NOT saved automatically')
disp(' ')

