function [freq_max,powerspec]=findfreq(signal,Fs,frequencies_to_analyze)
%FINDFREQ finds the peak frequency in the frequency spectrum of two signals
% By multiplying each of the two signals with a sine and a cosine at different
% frequencies and summing the resulting values, it is possible to obtain
% the spectral content of the two signals. This method is very efficient 
% for low frequency ranges.
% It is equivalent to projecting the multidimensional vector of the
% signal (where each sample is a dimension) to two orthonormal vectors
% forming a subspace (sin and cos) for each of the frequencies considered.
%
% in:
% signal    n x 2   Signals to be analyzed
% Fs        1       Sampling frequency
% frequencies_to_analyze 
%           1 x m   Frequencies that have to be analyzed      
%
% out:
% freq_max    1         frequency with the max power in the spectra
% powerspec   1 x m     spectral content of the two signals (summed)
% 
% This file is provided WITHOUT ANY WARRANTY
%
% Created by Massimiliano Di Luca 20/08/2009
% max@tuebingen.mpg.de
%
%
%
%
% to test, use:
%
% Fs=1000;
% signal_duration=10;
% tt=(1/Fs:1/Fs:signal_duration)*2*pi;
% sinusoidal_window=normpdf(1/Fs:1/Fs:signal_duration,signal_duration/2,signal_duration/2);
% sinusoidal_window=sinusoidal_window/max(sinusoidal_window);
% clear signalrr
% signalrr(:,1)=sin(tt*1.7);
% signalrr(:,2)=circshift(signalrr(:,1),.3*Fs);
% signalrr=signalrr.*[sinusoidal_window' sinusoidal_window'];
% signalrr=signalrr-repmat(mean(signalrr),size(signalrr,1),1);
% 
% [freq_max,powerspec]=findfreq(Fs,signalrr)

if nargin<3
    frequencies_to_analyze=.3:.01:3;
end
tt=(1/Fs:1/Fs:length(signal)/Fs)*2*pi;


for fa=frequencies_to_analyze
    ttfa=tt*fa;
    ss=sin(ttfa);
    cs=cos(ttfa);
    for sig12 =1:2
        sf=ss*signal(:,sig12) /length(tt);
        cf=cs*signal(:,sig12) /length(tt);
        norm(sig12,find(fa==frequencies_to_analyze))=   sqrt(sf^2+cf^2);
        phase(sig12,find(fa==frequencies_to_analyze))=  atan(cf./sf);
    end
end


freq_max_index=min((find(norm(1,:)==max(norm(1,:)'))),(find(norm(2,:)==max(norm(2,:)'))));
freq_max=frequencies_to_analyze(freq_max_index);
powerspec=sum(norm);
