function [p1,p2]=fsplot(iff,selectedvaluefrequency,selectedvaluetime,asynchrony,values_abscissa_top,values_ordinate_top,Fs,signal)
%FSPLOT plots one distribution on the top (either spectral power or cross correlation) and two signals on the bottom subplot (plus a sinusoid)
%
% [p1,p2]=fsplot(iff,selectedvaluefrequency,selectedvaluetime,asynchrony,values_abscissa_top,values_ordinate_top,Fs,signal)
% 
% in:
% iff                    1       pointer to the figure
% selectedvaluefrequency 1       value to highlight on the top graph (and frequency of the sinusoid signal on the bottom)
% selectedvaluetime      1       asynchrony added to the bottom sinusoid
%                              999 to not plot the sinusoid 
% asynchrony             1       relative asynchrony to shift the bottom signals in time
% values_abscissa_top    1 x m   range of values for the top graph
% values_ordinate_top    1 x m   distribution to be plotted on the top
% Fs                     1       sampling frequency
% signal                 n x 2   signal to be plotted on the bottom
%
% out: 
% p1,p2                  1 x 4   coordinates of the two graphs in the figure
% 
% This file is provided WITHOUT ANY WARRANTY
%
% Created by Massimiliano Di Luca 05/10/2009
% max@tuebingen.mpg.de

signal_duration=size(signal,1)/Fs;

figure(iff)
h1=subplot(2,1,1);
cla
hold on
plot(values_abscissa_top,values_ordinate_top)
if selectedvaluetime~=999
    plot(values_abscissa_top(min(abs(values_abscissa_top-selectedvaluefrequency))==abs(values_abscissa_top-selectedvaluefrequency)),...
        values_ordinate_top(min(abs(values_abscissa_top-selectedvaluefrequency))==abs(values_abscissa_top-selectedvaluefrequency)),'or')
else
    plot(values_abscissa_top(min(abs(values_abscissa_top-asynchrony))==abs(values_abscissa_top-asynchrony)),...
        values_ordinate_top(min(abs(values_abscissa_top-asynchrony))==abs(values_abscissa_top-asynchrony)),'or')

end
axis tight
h2=subplot(2,1,2);
cla
hold on
plot(1/Fs:1/Fs:signal_duration,signal(:,1),'b')
if selectedvaluetime~=999
    plot(1/Fs:1/Fs:signal_duration,circshift(signal(:,2)',-round(asynchrony*Fs))',':b')
    plot(1/Fs:1/Fs:signal_duration,sin((-selectedvaluetime+(1/Fs:1/Fs:signal_duration))*selectedvaluefrequency*2*pi)/max(std(signal)),'r')
else
    plot(1/Fs:1/Fs:signal_duration,circshift(signal(:,2),round(asynchrony*Fs)),'r')
end
axis([1/Fs signal_duration -4*max(std(signal)) 4*max(std(signal))])

p2=get(h2,'Position');
p1=get(h1,'Position');